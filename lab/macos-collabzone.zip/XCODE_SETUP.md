# CollabZone — Xcode Project Setup

## 1. Create the Xcode project

1. Open **Xcode → File → New → Project**
2. Choose **macOS → App**
3. Configure:
   - Product Name: `CollabZone`
   - Bundle Identifier: `com.yourname.CollabZone`
   - Interface: **SwiftUI**
   - Language: **Swift**
4. Save the project somewhere convenient

## 2. Replace the generated source

1. Delete the generated `ContentView.swift` and `CollabZoneApp.swift` that Xcode creates
2. Drag `CollabZoneApp.swift` from this folder into the Xcode project navigator
3. Make sure "Copy items if needed" is checked and the target is `CollabZone`

## 3. Info.plist — hide Dock icon

Add (or confirm) this key in `Info.plist`:

```xml
<key>LSUIElement</key>
<true/>
```

This prevents the app from appearing in the Dock.

## 4. Entitlements — allow outgoing network connections

In `CollabZone.entitlements` (create if it doesn't exist) add:

```xml
<key>com.apple.security.network.client</key>
<true/>
```

Or enable via: **Signing & Capabilities → + Capability → App Sandbox → Outgoing Connections (Client)**

## 5. Build & run

- **Cmd+R** to run in Xcode
- The app will appear in the menu bar as **🤝 CollabZone** (or the active status once the server responds)

---

# macOS Shortcut (optional)

To add a keyboard shortcut to open CollabZone:  
**System Settings → Keyboard → Keyboard Shortcuts → Services** and bind to the app.
