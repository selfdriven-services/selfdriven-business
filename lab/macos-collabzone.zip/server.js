/**
 * CollabZone State Server
 * Holds the current collaboration status (Curiosity / Caring / Constructive)
 * and exposes a simple REST API for the macOS menu bar app.
 *
 * Run: node server.js
 * Default port: 7742
 */

const http = require('http');
const PORT = process.env.PORT || 7742;

// ─── In-memory state ─────────────────────────────────────────────────────────
const VALID_STATUSES = ['Curiosity', 'Caring', 'Constructive'];

let state = {
  status: null,          // 'Curiosity' | 'Caring' | 'Constructive' | null
  updatedAt: null,       // ISO timestamp of last change
  history: [],           // last 20 status changes
  note: '',              // optional free-text note
};

// ─── Helpers ─────────────────────────────────────────────────────────────────
function now() { return new Date().toISOString(); }

function jsonResponse(res, statusCode, body) {
  const payload = JSON.stringify(body, null, 2);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(payload);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => data += chunk);
    req.on('end', () => {
      try { resolve(data ? JSON.parse(data) : {}); }
      catch (e) { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function pushHistory(status, note) {
  state.history.unshift({ status, note: note || '', at: now() });
  if (state.history.length > 20) state.history.pop();
}

// ─── Request router ───────────────────────────────────────────────────────────
async function handleRequest(req, res) {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = url.pathname;
  const method = req.method.toUpperCase();

  // CORS pre-flight
  if (method === 'OPTIONS') return jsonResponse(res, 204, {});

  // GET /status  — current state
  if (method === 'GET' && path === '/status') {
    return jsonResponse(res, 200, { ok: true, data: state });
  }

  // POST /status  — set status
  if (method === 'POST' && path === '/status') {
    let body;
    try { body = await readBody(req); }
    catch { return jsonResponse(res, 400, { ok: false, error: 'Invalid JSON body' }); }

    const { status, note } = body;

    if (!VALID_STATUSES.includes(status)) {
      return jsonResponse(res, 422, {
        ok: false,
        error: `Invalid status. Must be one of: ${VALID_STATUSES.join(', ')}`,
      });
    }

    pushHistory(status, note);
    state.status = status;
    state.note = note || '';
    state.updatedAt = now();

    console.log(`[${state.updatedAt}] Status → ${status}${note ? ` (${note})` : ''}`);
    return jsonResponse(res, 200, { ok: true, data: state });
  }

  // DELETE /status  — clear status (set to null)
  if (method === 'DELETE' && path === '/status') {
    pushHistory(null, 'cleared');
    state.status = null;
    state.note = '';
    state.updatedAt = now();
    console.log(`[${state.updatedAt}] Status cleared`);
    return jsonResponse(res, 200, { ok: true, data: state });
  }

  // GET /history  — last 20 changes
  if (method === 'GET' && path === '/history') {
    return jsonResponse(res, 200, { ok: true, data: state.history });
  }

  // GET /health
  if (method === 'GET' && path === '/health') {
    return jsonResponse(res, 200, { ok: true, uptime: process.uptime() });
  }

  return jsonResponse(res, 404, { ok: false, error: 'Not found' });
}

// ─── Start ────────────────────────────────────────────────────────────────────
const server = http.createServer(handleRequest);
server.listen(PORT, '127.0.0.1', () => {
  console.log(`CollabZone state server running on http://127.0.0.1:${PORT}`);
  console.log('Endpoints:');
  console.log('  GET    /status   — current status');
  console.log('  POST   /status   — set status  { "status": "Curiosity", "note": "..." }');
  console.log('  DELETE /status   — clear status');
  console.log('  GET    /history  — last 20 changes');
  console.log('  GET    /health   — uptime check');
});
