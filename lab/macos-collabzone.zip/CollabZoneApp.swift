import Cocoa
import SwiftUI

// ─── App entry point ─────────────────────────────────────────────────────────
@main
struct CollabZoneApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        // No main window — this is a menu-bar-only app
        Settings { EmptyView() }
    }
}

// ─── Data model ──────────────────────────────────────────────────────────────
enum CollabStatus: String, CaseIterable, Identifiable {
    case curiosity    = "Curiosity"
    case caring       = "Caring"
    case constructive = "Constructive"

    var id: String { rawValue }

    var emoji: String {
        switch self {
        case .curiosity:    return "🔭"
        case .caring:       return "💛"
        case .constructive: return "🔨"
        }
    }

    var color: Color {
        switch self {
        case .curiosity:    return Color(hex: "#4B9CD3")
        case .caring:       return Color(hex: "#E8805A")
        case .constructive: return Color(hex: "#5BAD8E")
        }
    }

    var description: String {
        switch self {
        case .curiosity:    return "Open to learning & exploring ideas"
        case .caring:       return "Focused on people & relationships"
        case .constructive: return "Building & solving together"
        }
    }

    var menuBarLabel: String { "\(emoji) \(rawValue)" }
}

// ─── State manager (talks to Node.js server) ─────────────────────────────────
@MainActor
class StatusManager: ObservableObject {
    static let shared = StatusManager()

    @Published var currentStatus: CollabStatus?
    @Published var lastUpdated: Date?
    @Published var isLoading = false
    @Published var serverReachable = false

    private let baseURL = URL(string: "http://127.0.0.1:7742")!
    private var pollTimer: Timer?

    init() { startPolling() }

    func startPolling() {
        fetchStatus()
        pollTimer = Timer.scheduledTimer(withTimeInterval: 10, repeats: true) { [weak self] _ in
            Task { await self?.fetchStatusAsync() }
        }
    }

    func fetchStatus() {
        Task { await fetchStatusAsync() }
    }

    func fetchStatusAsync() async {
        let url = baseURL.appendingPathComponent("status")
        do {
            let (data, resp) = try await URLSession.shared.data(from: url)
            guard let http = resp as? HTTPURLResponse, http.statusCode == 200 else { return }
            let decoded = try JSONDecoder().decode(StatusResponse.self, from: data)
            currentStatus = decoded.data.status.flatMap { CollabStatus(rawValue: $0) }
            lastUpdated   = decoded.data.updatedAt
            serverReachable = true
        } catch {
            serverReachable = false
        }
    }

    func setStatus(_ status: CollabStatus) {
        isLoading = true
        Task {
            let url = baseURL.appendingPathComponent("status")
            var req = URLRequest(url: url)
            req.httpMethod = "POST"
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            req.httpBody = try? JSONEncoder().encode(["status": status.rawValue])
            do {
                let (data, _) = try await URLSession.shared.data(for: req)
                let decoded = try JSONDecoder().decode(StatusResponse.self, from: data)
                currentStatus = decoded.data.status.flatMap { CollabStatus(rawValue: $0) }
                lastUpdated   = decoded.data.updatedAt
            } catch {}
            isLoading = false
        }
    }

    func clearStatus() {
        isLoading = true
        Task {
            let url = baseURL.appendingPathComponent("status")
            var req = URLRequest(url: url)
            req.httpMethod = "DELETE"
            do { let _ = try await URLSession.shared.data(for: req) } catch {}
            currentStatus = nil
            lastUpdated   = nil
            isLoading = false
        }
    }
}

// ─── Decodable models ─────────────────────────────────────────────────────────
struct StatusResponse: Decodable {
    let ok: Bool
    let data: StatusData
}

struct StatusData: Decodable {
    let status: String?
    let updatedAt: Date?

    enum CodingKeys: String, CodingKey { case status, updatedAt }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        status = try c.decodeIfPresent(String.self, forKey: .status)
        if let raw = try c.decodeIfPresent(String.self, forKey: .updatedAt) {
            let fmt = ISO8601DateFormatter()
            fmt.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            updatedAt = fmt.date(from: raw) ?? ISO8601DateFormatter().date(from: raw)
        } else {
            updatedAt = nil
        }
    }
}

// ─── App delegate (menu bar controller) ──────────────────────────────────────
class AppDelegate: NSObject, NSApplicationDelegate {
    var statusItem: NSStatusItem!
    var popover: NSPopover!

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory) // hide dock icon

        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        if let btn = statusItem.button {
            btn.title = "🤝"
            btn.action = #selector(togglePopover(_:))
            btn.target  = self
        }

        popover = NSPopover()
        popover.contentSize  = NSSize(width: 320, height: 480)
        popover.behavior     = .transient
        popover.contentViewController = NSHostingController(
            rootView: CollabZoneView()
                .environmentObject(StatusManager.shared)
        )

        // Update menu bar icon when status changes
        NotificationCenter.default.addObserver(
            self, selector: #selector(updateIcon),
            name: .statusChanged, object: nil
        )

        // Trigger first icon update after brief delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { self.updateIcon() }
    }

    @objc func togglePopover(_ sender: Any?) {
        if let btn = statusItem.button {
            if popover.isShown {
                popover.performClose(sender)
            } else {
                popover.show(relativeTo: btn.bounds, of: btn, preferredEdge: .minY)
                popover.contentViewController?.view.window?.makeKey()
            }
        }
    }

    @objc func updateIcon() {
        Task { @MainActor in
            let s = StatusManager.shared.currentStatus
            statusItem.button?.title = s?.menuBarLabel ?? "🤝 CollabZone"
        }
    }
}

extension Notification.Name {
    static let statusChanged = Notification.Name("CollabZone.statusChanged")
}

// ─── SwiftUI popover view ─────────────────────────────────────────────────────
struct CollabZoneView: View {
    @EnvironmentObject var manager: StatusManager

    var body: some View {
        ZStack {
            Color(hex: "#0F0F0F").ignoresSafeArea()

            VStack(spacing: 0) {
                // Header
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("CollabZone")
                            .font(.custom("SF Pro Display", size: 18).weight(.bold))
                            .foregroundColor(.white)
                        HStack(spacing: 6) {
                            Circle()
                                .fill(manager.serverReachable ? Color(hex: "#5BAD8E") : Color(hex: "#E8805A"))
                                .frame(width: 6, height: 6)
                            Text(manager.serverReachable ? "Server connected" : "Server offline")
                                .font(.system(size: 11))
                                .foregroundColor(Color(hex: "#888888"))
                        }
                    }
                    Spacer()
                    Button(action: { manager.fetchStatus() }) {
                        Image(systemName: "arrow.clockwise")
                            .foregroundColor(Color(hex: "#888888"))
                            .font(.system(size: 13))
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 16)

                // Current status indicator
                currentStatusBadge
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)

                // Status selector cards
                VStack(spacing: 10) {
                    ForEach(CollabStatus.allCases) { status in
                        StatusCard(status: status, isSelected: manager.currentStatus == status) {
                            manager.setStatus(status)
                            NotificationCenter.default.post(name: .statusChanged, object: nil)
                        }
                    }
                }
                .padding(.horizontal, 16)

                // Clear + footer
                if manager.currentStatus != nil {
                    Button(action: {
                        manager.clearStatus()
                        NotificationCenter.default.post(name: .statusChanged, object: nil)
                    }) {
                        Text("Clear Status")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(Color(hex: "#666666"))
                            .padding(.vertical, 8)
                            .padding(.horizontal, 16)
                            .background(Color(hex: "#1E1E1E"))
                            .cornerRadius(8)
                    }
                    .buttonStyle(.plain)
                    .padding(.top, 14)
                }

                Spacer()

                // Last updated
                if let date = manager.lastUpdated {
                    Text("Updated \(date.formatted(.relative(presentation: .named)))")
                        .font(.system(size: 10))
                        .foregroundColor(Color(hex: "#555555"))
                        .padding(.bottom, 16)
                }
            }
        }
    }

    @ViewBuilder
    var currentStatusBadge: some View {
        if let s = manager.currentStatus {
            HStack(spacing: 10) {
                Text(s.emoji)
                    .font(.system(size: 22))
                VStack(alignment: .leading, spacing: 2) {
                    Text("You're in \(s.rawValue) mode")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.white)
                    Text(s.description)
                        .font(.system(size: 11))
                        .foregroundColor(Color(hex: "#888888"))
                }
                Spacer()
            }
            .padding(14)
            .background(s.color.opacity(0.12))
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(s.color.opacity(0.35), lineWidth: 1)
            )
            .cornerRadius(12)
        } else {
            HStack {
                Image(systemName: "hand.raised.fill")
                    .foregroundColor(Color(hex: "#555555"))
                Text("No status set — pick one below")
                    .font(.system(size: 12))
                    .foregroundColor(Color(hex: "#666666"))
            }
            .frame(maxWidth: .infinity)
            .padding(14)
            .background(Color(hex: "#1A1A1A"))
            .cornerRadius(12)
        }
    }
}

// ─── Status card ─────────────────────────────────────────────────────────────
struct StatusCard: View {
    let status: CollabStatus
    let isSelected: Bool
    let action: () -> Void

    @State private var hovered = false

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                ZStack {
                    Circle()
                        .fill(status.color.opacity(isSelected ? 0.25 : 0.10))
                        .frame(width: 44, height: 44)
                    Text(status.emoji)
                        .font(.system(size: 20))
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text(status.rawValue)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(isSelected ? .white : Color(hex: "#CCCCCC"))
                    Text(status.description)
                        .font(.system(size: 11))
                        .foregroundColor(Color(hex: "#777777"))
                        .lineLimit(1)
                }

                Spacer()

                if isSelected {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(status.color)
                        .font(.system(size: 16))
                } else {
                    Image(systemName: "circle")
                        .foregroundColor(Color(hex: "#333333"))
                        .font(.system(size: 16))
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .background(
                isSelected
                    ? status.color.opacity(0.12)
                    : (hovered ? Color(hex: "#1E1E1E") : Color(hex: "#161616"))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(
                        isSelected ? status.color.opacity(0.4) : Color(hex: "#2A2A2A"),
                        lineWidth: 1
                    )
            )
            .cornerRadius(12)
            .scaleEffect(hovered && !isSelected ? 1.01 : 1.0)
            .animation(.easeInOut(duration: 0.15), value: hovered)
        }
        .buttonStyle(.plain)
        .onHover { h in hovered = h }
    }
}

// ─── Color(hex:) extension ───────────────────────────────────────────────────
extension Color {
    init(hex: String) {
        let h = hex.trimmingCharacters(in: .init(charactersIn: "#"))
        let v = UInt64(h, radix: 16) ?? 0
        let r = Double((v >> 16) & 0xFF) / 255
        let g = Double((v >>  8) & 0xFF) / 255
        let b = Double(        v & 0xFF) / 255
        self.init(red: r, green: g, blue: b)
    }
}
