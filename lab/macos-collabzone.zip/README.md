# 🤝 CollabZone

A macOS menu-bar app for setting and sharing your collaboration mode — **Curiosity**, **Caring**, or **Constructive** — backed by a lightweight Node.js state server.

```
collabzone/
├── server/
│   ├── server.js                    ← Node.js REST state server (zero dependencies)
│   ├── package.json
│   └── com.collabzone.server.plist  ← LaunchAgent for auto-start on login
└── app/
    ├── CollabZoneApp.swift          ← macOS SwiftUI menu-bar app
    └── XCODE_SETUP.md              ← Xcode project setup instructions
```

---

## Quick Start

### 1. Start the state server

```bash
cd server
node server.js
# → CollabZone state server running on http://127.0.0.1:7742
```

No npm install needed — zero external dependencies.

### 2. Test the API

```bash
# Get current status
curl http://127.0.0.1:7742/status

# Set status to Curiosity
curl -X POST http://127.0.0.1:7742/status \
  -H "Content-Type: application/json" \
  -d '{"status": "Curiosity", "note": "Exploring new ideas"}'

# Set status to Caring
curl -X POST http://127.0.0.1:7742/status \
  -H "Content-Type: application/json" \
  -d '{"status": "Caring"}'

# Set status to Constructive
curl -X POST http://127.0.0.1:7742/status \
  -H "Content-Type: application/json" \
  -d '{"status": "Constructive"}'

# Clear status
curl -X DELETE http://127.0.0.1:7742/status

# View history (last 20 changes)
curl http://127.0.0.1:7742/history

# Health check
curl http://127.0.0.1:7742/health
```

### 3. Build & run the macOS app

Follow `app/XCODE_SETUP.md` to open the Swift source in Xcode, configure entitlements, and run.

The menu bar icon updates automatically:
- **🤝 CollabZone** — no status set
- **🔭 Curiosity** — curiosity mode
- **💛 Caring** — caring mode
- **🔨 Constructive** — constructive mode

---

## API Reference

| Method   | Path       | Body                              | Description           |
|----------|------------|-----------------------------------|-----------------------|
| `GET`    | `/status`  | —                                 | Current status        |
| `POST`   | `/status`  | `{"status":"Curiosity","note":"…"}` | Set status          |
| `DELETE` | `/status`  | —                                 | Clear status          |
| `GET`    | `/history` | —                                 | Last 20 changes       |
| `GET`    | `/health`  | —                                 | Server uptime         |

Valid status values: `Curiosity`, `Caring`, `Constructive`

---

## Auto-start on login (optional)

Edit `server/com.collabzone.server.plist` with your username and Node.js path, then:

```bash
cp server/com.collabzone.server.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.collabzone.server.plist
```

---

## The Three Modes

| Mode | Emoji | Meaning |
|------|-------|---------|
| **Curiosity** | 🔭 | Open to exploring, questioning, and learning |
| **Caring** | 💛 | Focused on people, relationships, and empathy |
| **Constructive** | 🔨 | In build mode — solving and making progress |
